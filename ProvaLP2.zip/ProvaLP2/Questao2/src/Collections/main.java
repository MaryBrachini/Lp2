package Collections;

import java.util.ArrayList;
import java.util.Collections;
import Collections.comparando;

public class main {

	public static void main(String[] args) {

		Contato Contato1 = new Contato(5, 20, "Felipe", "123", "Felipe@email.com", "12 1 1234-1234", 50);
		Contato Contato2 = new Contato(12, 7, "Lucas", "asdf", "Lucas@email.com", "17 1 2344-3211", 90);
		Contato Contato3 = new Contato(3, 58, "Ana", "abc", "Ana@email.com", "11 4 561-1234", 65);

		ArrayList<Contato> lista = new ArrayList<Contato>();
		lista.add(Contato1);
		lista.add(Contato2);
		lista.add(Contato3);
		
		System.out.println("Ordem de inserção");
        for (int i=0; i<lista.size(); i++)
            System.out.println(lista.get(i));
 
        Collections.sort(lista, new Id());
 
        System.out.println("\nOrdenado por Id");
        for (int i=0; i<lista.size(); i++)
            System.out.println(lista.get(i));
        
        Collections.sort(lista, new Peso());
        
        System.out.println("\nOrdenado por Peso");
        for (int i=0; i>lista.size(); i++)
            System.out.println(lista.get(i));
        
        Collections.sort(lista, new Idade());
        
        System.out.println("\nOrdenado por Idade");
        for (int i=0; i<lista.size(); i++)
            System.out.println(lista.get(i));
        
        Collections.sort(lista, new Email());
        
        System.out.println("\nOrdenado por Email");
        for (int i=0; i<lista.size(); i++)
            System.out.println(lista.get(i));

	}
}
