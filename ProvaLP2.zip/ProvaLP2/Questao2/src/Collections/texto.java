package Collections;

public class texto {
	/**
	 * Crie uma classe entidade (métodos getters e setters) 
	 * “Contato” com os
	 * atributos: id (int), nome (string), password (string),
	 *  e-mail (string),
	 * telefone (string), idade (int), peso (float).
	 * 
	 * Considerando que objetos da classe “Contato” estão em 
	 * uma List, utilize os
	 * métodos Collections.sort(), Collections.max() e 
	 * Collections.min()
	 * 
	 * implementações da interface Comparator para: 
	 * • Identificar na lista, o objeto
	 * Contato com o menor peso.
	 * 
	 *  • Identificar na lista,
	 *  o objeto Contato com o
	 * maior idade. 
	 * 
	 * • Identificar na lista, os objetos 
	 * Contato com o e-mail mais
	 * longo e o mais curto. 
	 * 
	 * • Ordenar a lista de objetos 
	 * Contato pelo id de forma
	 * crescente.
	 * 
	 *  • Crie casos de teste em JUnit para 
	 * ilustrar cada uma das
	 * funcionalidades implementadas.
	 */
}
