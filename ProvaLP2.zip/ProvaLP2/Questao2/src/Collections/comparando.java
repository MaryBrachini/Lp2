package Collections;

import java.util.Comparator;

public abstract class comparando implements Comparator<Contato>{
	
	 public float Peso(Contato a, Contato b){
	        return a.peso - b.peso;
	    }
	 
	 public int Idade(Contato a, Contato b){
	        return a.idade - b.idade;
	    }
	 public String Email(Contato a, Contato b){
	        return a.email - b.email;
	    }
	 
	 public int Id(Contato a, Contato b){
	        return a.id - b.id;
	    }
	 
	 
}
