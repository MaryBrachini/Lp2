package Exceptions;

public class ContatoDAO {	
	
public void salvar() {
	 if (idade <> 0){
		 if (idade > 5) and(idade < 99) {
			 
		 }
	 }
	 
	 if (peso <> 0){
		 if (peso > 1) and(idade < 200) {
			 
		 }
	 }
}
	
}
