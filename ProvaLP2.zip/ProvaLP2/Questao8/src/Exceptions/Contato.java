package Exceptions;

public class Contato {
	public int id, idade;
	public String nome, password, telefone, email;
	public float peso;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public Contato(int id, int idade, String nome, String password, String email, String telefone, float peso) {
        this.id = id;
        this.idade = idade;
        this.nome = nome;
        this.password = password;
        this.email = email;
        this.telefone = telefone;
        this.peso = peso;
    }

    @Override
    public String toString() {
        return "Contato{" + "id=" + id + ", idade=" + idade + ", nome=" + nome + ", password=" + password + ", email=" + email + ", telefone=" + telefone + ", peso=" + peso + '}';
    }
	
	
	
	
	
	
	
}