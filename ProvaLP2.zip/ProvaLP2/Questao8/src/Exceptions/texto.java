package Exceptions;

public class texto {
/**Crie uma classe “Contato” com os atributos: nome, password, e-mail,
telefone, idade, peso. Crie uma classe chamada ContatoDAO com um método “salvar()” que recebe
como parâmetro um objeto da classe Contato. O método “salvar()” deve lançar exceções,
considerando que:
• Os campos nome, password e e-mail são obrigatórios.
• A idade se não for vazia (ou seja, igual a zero) deve estar entre 5 e 99 anos.
• O peso se não for vazio (ou seja, igual a zero) deve estar entre 1 e 200 kg.
Crie uma exceção para cada possível erro, lembrando que todas devem ser do tipo “checked
exceptions”. Crie casos de teste em JUnit para verificar cada um dos possíveis erros.*/
}
