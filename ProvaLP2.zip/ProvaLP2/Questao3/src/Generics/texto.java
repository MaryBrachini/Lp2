package Generics;

public class texto {
/**Escreva uma implementação usando generics para a estrutura de dados pilha.
Considere que:
• Tal pilha possui um tamanho limitado (que deve ser passado como parâmetro no
construtor).
• Adicione métodos para empilhar, desempilhar e verificar se a pilha está vazia.
• Crie duas classes de exceção que devem ser do tipo “checked exception”:
PilhaVaziaException e PilhaCheiaException.
• PilhaVaziaException deve ser lançada caso tente desempilhar a pilha sem elementos.
• PilhaCheiaException deve ser lançada caso tente empilhar um elemento na pilha cheia.
• Implemente casos de teste em JUnit, trabalhando com Strings, que ilustrem a utilização dos
métodos e as possíveis exceções lançadas.*/
}
