package Herança;

public class texto {
/**Implemente as quatro classes a seguir. Use a identação
correta, rode o programa e ao final, adicione comentários nos pontos em que você não conseguir
entender diretamente ao ler o código pela primeira vez.


Empregado.java
public class Empregado {
private String nome;
private double salario;
public Empregado() {
nome = "";
salario = 0;
}
public final double getSalario() {
return salario;
}
protected void setSalario(double salario) {
this.salario = (salario>=0) ? salario : 0;
}
protected final void setNome(String nome) {
this.nome = (nome != null) ? nome : "";
}
public final String getNome() {
return nome;
}
protected void reajusteSalario(double valor) {
//código a ser implementado em subclasses
}
}


Programador.java
package aulas;
public final class Programador extends Empregado {
private double peso_salario;
public Programador(String nome, double salario) {
super();
peso_salario = 0;
super.setNome(nome);
setSalario(salario);
}
public double getPesoSalario() {
return peso_salario;
}
public void setPesoSalario(double peso_salario) {
if (peso_salario >= 0 && peso_salario <= 0.1) {
this.peso_salario = peso_salario;
}
else {
throw new IllegalArgumentException("Peso não está entre 0 e 0.1: " + peso_salario);*/
}
