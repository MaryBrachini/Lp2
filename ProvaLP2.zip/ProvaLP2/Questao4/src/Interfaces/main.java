package Interfaces;

import java.util.Scanner;

public class main {
	public static void main(String[] args) {

		Scanner entradaq = new Scanner(System.in);
		Scanner entradar = new Scanner(System.in);

		/* Quadrado */
		Quadrado q = new Quadrado();
		q.construtor();
		q.imprimir();

		/* Retangulo */
		Retangulo r = new Retangulo();
		r.construtor();
		r.imprimir();
	}
}
