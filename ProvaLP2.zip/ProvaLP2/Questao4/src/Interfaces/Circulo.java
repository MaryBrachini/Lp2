package Interfaces;

public class Circulo {
	private float raio;
}
