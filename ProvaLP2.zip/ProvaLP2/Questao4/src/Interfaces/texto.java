package Interfaces;

public class texto {
/**Dado a interface abaixo, desenvolva as classes
 *  Quadrado, Retângulo,
Circulo e Trapezio que implementam tal interface.
 Armazene objetos dessas diferentes classes em
uma mesma lista e imprima a área de cada objeto.

interface AreaCalculavel{
 double calculaArea();
}*/
}
