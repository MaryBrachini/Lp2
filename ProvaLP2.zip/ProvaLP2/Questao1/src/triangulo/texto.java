package triangulo;

public class texto {
	/**
	 * Triângulo O programa lê três valores inteiros 
	 * que representam os lados de um
	 * triângulo.
	 * 
	 *se os lados formam um  triângulo isósceles,
	 * escaleno ou equilátero. 
	 * 
	 * Condição: a soma de dois lados tem que ser maior
	 * que o terceiro lado. 
	 * 
	 * (i) Defina o esqueleto de uma 
	 * classe Java que resolva
	 * o problema acima. 
	 * 
	 * 
	 * 
	 * (ii) Escreva casos de teste em
	 *  JUnit para as seguintes
	 * situações: 
	 * 
	 * Triângulo escaleno válido. 
	 * 
	 * //• Triângulo isósceles válido.
	 * 
	 * Triângulo equilátero válido. 
	 * 
	 * //• Pelo menos 3 casos de teste (CTs) para
	 * isósceles válido contendo a permutação dos mesmos 
	 * 
	 * //valores. //• Um valor
	 * zero. //• Um valor negativo. 
	 * 
	 * //• A soma de 2 lados é igual ao terceiro lado.
	 * //• Para o item acima, um CT para cada permutação 
	 * de valores. //• CT em que a
	 * soma de 2 lados é menor que o terceiro lado.
	 * 
	 *  //• Para o item acima, um CT
	 * para cada permutação de valores. 
	 * 
	 * //• Um CT para os três valores iguais a
	 * zero.
	 */
}
