package triangulo;

public class calcTri extends tria {

	public calcTri(int l1, int l2, int l3) {
		super(l1, l2, l3);
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {

		tria triangulo1 = new tria(5, 5, 5);
		tria triangulo2 = new tria(7, 7, 2);
		tria triangulo3 = new tria(10, 5, 3);

		if ((l1 < l2 + l3) && (l2 < l1 + l3) && (l3 < l1 + l2)) {
			if (l1 == l2 && l1 == l3) {
				System.out.println("Triangulo Equilatero");
			} else if ((l1 == l2) || (l1 == l3)) {
				System.out.println("Triangulo Isosceles");
			} else
				System.out.println("Triângulo Escaleno");
		} else {
			System.out.println("Não é um triangulo!");
		}
	}
}
